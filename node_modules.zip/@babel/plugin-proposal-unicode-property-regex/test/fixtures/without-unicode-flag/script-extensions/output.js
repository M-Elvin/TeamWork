var regex = /(?:\uD811[\uDC00-\uDE46])/;
