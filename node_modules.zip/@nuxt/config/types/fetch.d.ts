/**
 * NuxtConfigurationFetch
 * Documentation: ?
 */

export interface NuxtConfigurationFetch {
  client?: boolean
  server?: boolean
}
