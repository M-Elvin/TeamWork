export default function devalue(value: any, level?: string): string;
