const { resolve } = require('path')

module.exports = {
  base: resolve(__dirname, 'base'),
  consola: resolve(__dirname, 'consola')
}
