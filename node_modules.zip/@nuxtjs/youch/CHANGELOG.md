<a name="2.0.5"></a>
## [2.0.5](https://github.com/poppinss/youch/compare/v2.0.4...v2.0.5) (2017-06-13)


### Bug Fixes

* **template:** improve css for smaller screens ([b07c77d](https://github.com/poppinss/youch/commit/b07c77d))



<a name="2.0.4"></a>
## [2.0.4](https://github.com/poppinss/youch/compare/v2.0.3...v2.0.4) (2017-01-31)


### Bug Fixes

* **test:** use mocha instead of japa ([8bf7039](https://github.com/poppinss/youch/commit/8bf7039))



<a name="2.0.3"></a>
## [2.0.3](https://github.com/poppinss/youch/compare/v2.0.2...v2.0.3) (2017-01-30)


### Bug Fixes

* **regex:** use plain regex over path.sep ([db3e2dc](https://github.com/poppinss/youch/commit/db3e2dc))



<a name="2.0.2"></a>
## [2.0.2](https://github.com/poppinss/youch/compare/v2.0.0...v2.0.2) (2017-01-27)


### Bug Fixes

* **package:** fix path to main file ([5ad3b4a](https://github.com/poppinss/youch/commit/5ad3b4a))



<a name="2.0.1"></a>
## [2.0.1](https://github.com/poppinss/youch/compare/v2.0.0...v2.0.1) (2017-01-26)


### Bug Fixes

* **package:** fix path to main file ([5ad3b4a](https://github.com/poppinss/youch/commit/5ad3b4a))



<a name="2.0.0"></a>
# 2.0.0 (2017-01-26)


### Features

* initial implementation ([aba222a](https://github.com/poppinss/youch/commit/aba222a))



